<?php

function geminiHttpPost(string $url, array $payload, string $apiKey): ?array
{
    $jsonPayload = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if ($jsonPayload === false) {
        return null;
    }

    $headers = [
        'Content-Type: application/json',
        'x-goog-api-key: ' . $apiKey,
    ];

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => $jsonPayload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
        ]);

        $response = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false || $httpCode < 200 || $httpCode >= 300) {
            return null;
        }

        $data = json_decode($response, true);
        return is_array($data) ? $data : null;
    }

    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => implode("\r\n", $headers),
            'content' => $jsonPayload,
            'timeout' => 15,
        ],
    ]);

    $response = @file_get_contents($url, false, $context);
    if ($response === false) {
        return null;
    }

    $data = json_decode($response, true);
    return is_array($data) ? $data : null;
}

function geminiExtractText(array $response): string
{
    $parts = $response['candidates'][0]['content']['parts'] ?? [];
    $text = '';

    foreach ($parts as $part) {
        if (!empty($part['text'])) {
            $text .= $part['text'];
        }
    }

    return trim($text);
}

function generateGeminiResultFeedback(array $context): ?string
{
    $apiKeysPath = __DIR__ . '/../config/api_keys.php';

    if (!file_exists($apiKeysPath)) {
        return null;
    }

    $apiKeys = require $apiKeysPath;
    $geminiApiKey = $apiKeys['gemini'] ?? '';

    if (!$geminiApiKey) {
        return null;
    }

    $matches = empty($context['matches']) ? 'none' : implode(', ', $context['matches']);
    $concerns = empty($context['concerns']) ? 'none' : implode(', ', $context['concerns']);

    $prompt = "Vehicle: {$context['vehicle_name']}\n"
        . "Type: {$context['vehicle_type']}\n"
        . "Compatibility score: {$context['compatibility']}\n"
        . "Regret prediction: {$context['regret']}\n"
        . "User preference scores: " . json_encode($context['user_scores']) . "\n"
        . "Vehicle scores: " . json_encode($context['vehicle_scores']) . "\n"
        . "Strong matches: {$matches}\n"
        . "Main concerns: {$concerns}\n\n"
        . "Write exactly 3 concise sentences for a student vehicle recommendation page. "
        . "Mention the strongest fit, mention one important concern if there is one, and give a practical final recommendation. "
        . "Do not use markdown, bullet points, headings, or mention that you are an AI.";

    $payload = [
        'system_instruction' => [
            'parts' => [
                [
                    'text' => 'You write concise, practical vehicle compatibility feedback for a web app.',
                ],
            ],
        ],
        'contents' => [
            [
                'role' => 'user',
                'parts' => [
                    [
                        'text' => $prompt,
                    ],
                ],
            ],
        ],
        'generationConfig' => [
            'temperature' => 0.4,
            'topP' => 0.9,
            'maxOutputTokens' => 180,
        ],
    ];

    $response = geminiHttpPost(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
        $payload,
        $geminiApiKey
    );

    if (!$response) {
        return null;
    }

    $text = geminiExtractText($response);
    return $text !== '' ? $text : null;
}
