<?php

return [
    'client_id' => '338479804269-vuc2hn0rbi2g3037kn345u560fvf007m.apps.googleusercontent.com',
    'client_secret' => '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',
    'redirect_uri' => 'http://localhost/vehicle-personality-matcher/auth/google/callback.php',
];
