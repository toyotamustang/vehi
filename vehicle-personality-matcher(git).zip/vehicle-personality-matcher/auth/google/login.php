<?php
session_start();

try {
    require_once "config.php";
} catch (Throwable $e) {
    $_SESSION['google_oauth_error'] = $e->getMessage();
    header("Location: ../../login.php");
    exit;
}

$_SESSION['google_oauth_state'] = bin2hex(random_bytes(16));
$login_url = buildGoogleAuthUrl($_SESSION['google_oauth_state']);

header("Location: " . $login_url);
exit;
