<?php
require_once "../../includes/db.php";
require_once "config.php";

session_start();

if (!isset($_GET['code'])) {
    header("Location: ../../login.php");
    exit;
}

// get token
$token = $client->fetchAccessTokenWithAuthCode($_GET['code']);

if (isset($token['error'])) {
    die("Google authentication failed.");
}

$client->setAccessToken($token['access_token']);

// get user info
$oauth = new Google_Service_Oauth2($client);
$userData = $oauth->userinfo->get();

$email = $userData->email;
$name = $userData->name;
$google_id = $userData->id;

// -----------------------------
// 1. CHECK IF USER EXISTS
// -----------------------------
$stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {

    $user_id = $user['user_id'];

    // 🔗 LINK GOOGLE IF NOT LINKED
    if (empty($user['google_id'])) {
        $update = $conn->prepare("UPDATE users SET google_id=? WHERE user_id=?");
        $update->bind_param("si", $google_id, $user_id);
        $update->execute();
    }

} else {

    // -----------------------------
    // 2. CREATE NEW USER
    // -----------------------------

    // generate unique username
    $baseUsername = explode('@', $email)[0];
    $username = $baseUsername;
    $count = 1;

    while (true) {
        $check = $conn->prepare("SELECT user_id FROM users WHERE username=?");
        $check->bind_param("s", $username);
        $check->execute();
        $check->store_result();

        if ($check->num_rows == 0) break;

        $username = $baseUsername . $count;
        $count++;
    }

    // insert user (NO password yet)
    $insert = $conn->prepare("
        INSERT INTO users (name, username, email, password, role, is_verified, google_id)
        VALUES (?, ?, ?, '', 'user', 1, ?)
    ");
    $insert->bind_param("ssss", $name, $username, $email, $google_id);
    $insert->execute();

    $user_id = $insert->insert_id;

    // fetch inserted user
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id=?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
}

// -----------------------------
// 3. SET SESSION
// -----------------------------
$_SESSION['user_id'] = $user_id;
$_SESSION['name'] = $user['name'];
$_SESSION['role'] = $user['role'];

// -----------------------------
// 4. FORCE PASSWORD SET
// -----------------------------
if (empty($user['password'])) {
    header("Location: ../../auth/set-password.php");
    exit;
}

// -----------------------------
// 5. NORMAL LOGIN
// -----------------------------
header("Location: ../../user/dashboard.php");
exit;