<?php
require_once __DIR__ . '/../../vendor/autoload.php';

$client = new Google_Client();

$client->setClientId('338479804269-vuc2hn0rbi2g3037kn345u560fvf007m.apps.googleusercontent.com');
$client->setClientSecret('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');

$client->setRedirectUri('http://localhost/vehicle-personality-matcher/auth/google/callback.php');

$client->addScope("email");
$client->addScope("profile");