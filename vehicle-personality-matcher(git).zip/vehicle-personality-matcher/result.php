<?php
session_start();
ini_set('display_errors',1);
error_reporting(E_ALL);

include 'includes/db.php';
include 'includes/header.php';
include 'includes/gemini_feedback.php';

function formatTraitLabel(string $trait): string
{
    return ucfirst(str_replace('_', ' ', $trait));
}

function buildFallbackFeedback(string $name, int $compatibility, array $matches, array $concerns): string
{
    if ($compatibility >= 80) {
        $tone = $name . " looks like a strong fit for your overall driving profile.";
    } elseif ($compatibility >= 60) {
        $tone = $name . " is a decent match, but it comes with a few trade-offs.";
    } else {
        $tone = $name . " may not be the most natural fit for your current preferences.";
    }

    if (!empty($matches)) {
        $tone .= " It aligns best with your preference for " . implode(', ', $matches) . ".";
    }

    if (!empty($concerns)) {
        $tone .= " The main areas to think about are " . implode(', ', $concerns) . ".";
    } else {
        $tone .= " No major mismatch stands out from the quiz.";
    }

    return $tone;
}

/* ===============================
   RECEIVE QUIZ DATA
================================ */

if(!isset($_GET['show'])){

$type = $_POST['vehicle_type'] ?? '';
$id   = (int)($_POST['vehicle_id'] ?? 0);

if(!$type || !$id){
    die("Invalid request");
}

/* ===============================
   USER PERSONALITY VECTOR
================================ */

/* ===============================
   ROAD TYPE NORMALIZATION
================================ */

$roadScore = match((int)($_POST['road_type'] ?? 3)){
    1 => 35,
    2 => 55,
    3 => 72,
    4 => 95,
    default => 70
};

/* ===============================
   USER PERSONALITY VECTOR (FIXED)
================================ */

$user = [

'performance' => (
    (int)$_POST['performance'] * 0.85 +
    (int)$_POST['usage'] * 0.15
),

'comfort' => (
    (int)$_POST['comfort'] * 0.60 +
    $roadScore * 0.40
),

'efficiency' => (
    (int)$_POST['mileage'] * 0.75 +
    (int)$_POST['usage'] * 0.25
),

'practicality' => (
    (int)$_POST['practicality'] * 0.45 +
    (int)$_POST['passengers'] * 0.35 +
    $roadScore * 0.20
),

'reliability' => (
    (int)$_POST['maintenance'] * 0.50 +
    (int)$_POST['ownership'] * 0.20 +
    (int)$_POST['cost_sensitivity'] * 0.30
)

];

$_SESSION['performance']  = $user['performance'];
$_SESSION['comfort']      = $user['comfort'];
$_SESSION['efficiency']   = $user['efficiency'];
$_SESSION['reliability']  = $user['reliability'];
$_SESSION['practicality'] = $user['practicality'];

$_SESSION['quiz_vehicle_type'] = $type;
$_SESSION['quiz_vehicle_id']   = $id;

/* redirect once */



}

$type = $_SESSION['quiz_vehicle_type'] ?? '';
$id   = $_SESSION['quiz_vehicle_id'] ?? 0;

$user = [
'performance'  => $_SESSION['performance'],
'comfort'      => $_SESSION['comfort'],
'efficiency'   => $_SESSION['efficiency'],
'reliability'  => $_SESSION['reliability'],
'practicality' => $_SESSION['practicality']
];
/* ===============================
   FETCH VEHICLE
================================ */

if($type === 'bike'){

$stmt = $conn->prepare("SELECT * FROM bikes WHERE id=?");
$stmt->bind_param("i",$id);

}else{

$stmt = $conn->prepare("SELECT * FROM vehicle WHERE id=?");
$stmt->bind_param("i",$id);

}

$stmt->execute();
$res = $stmt->get_result();

if($res->num_rows === 0){
die("Vehicle not found");
}

$vehicle = $res->fetch_assoc();

/* ===============================
   REAL TIME MAINTENANCE SCORE
================================ */

function calculateMaintenance($vehicle,$type){

if($type === 'bike'){

$cc = $vehicle['displacement_cc'] ?? 150;
$hp = $vehicle['power_hp'] ?? 10;
$weight = $vehicle['weight_kg'] ?? 150;

$score = 100 - (
($cc * 0.03) +
($hp * 0.8) +
($weight * 0.05)
);

}else{

$mpg = $vehicle['city_mpg'] ?? 25;
$weight = $vehicle['weight_kg'] ?? 1500;

$score = ($mpg * 2) - ($weight * 0.01);

}

return max(20,min(100,round($score)));

}

$maintenanceScore = calculateMaintenance($vehicle,$type);

/* ===============================
   VEHICLE PERSONALITY VECTOR
================================ */

$vehicleVector = [

'performance'  => $vehicle['performance_score'] ?? 50,
'comfort'      => $vehicle['comfort_score'] ?? 50,
'efficiency'   => $vehicle['efficiency_score'] ?? 50,
'practicality' => $vehicle['practicality_score'] ?? 50,

'reliability'  => (
    ($vehicle['reliability_score'] ?? 50) +
    $maintenanceScore
)/2

];

/* ===============================
   DISTANCE SCORE
================================ */

$distance = 0;

foreach($user as $key=>$value){

    $diff = abs($value - $vehicleVector[$key]);

    if ($diff > 40) {
    $distance += $diff * 1.3;   // strong penalty
}
elseif ($diff > 20) {
    $distance += $diff * 1.15;  // 🔥 NEW: medium penalty
}
else {
    $distance += $diff;
}
}

// penalties
if (abs($user['performance'] - $vehicleVector['performance']) > 40) {
    $distance += 60;
}

if (abs($user['reliability'] - $vehicleVector['reliability']) > 40) {
    $distance += 50;
}

$maxDistance = count($user) * 180;
$maxDistance = count($user) * 180;

$distanceScore = 100 - (($distance / $maxDistance) * 100);

/* ===============================
   COSINE SIMILARITY
================================ */

function cosineSimilarity($A,$B){

$dot = 0;
$magA = 0;
$magB = 0;

foreach($A as $key=>$value){

$dot  += $A[$key] * $B[$key];
$magA += pow($A[$key],2);
$magB += pow($B[$key],2);

}

return $dot / (sqrt($magA) * sqrt($magB));

}


/* ===============================
   FINAL COMPATIBILITY
================================ */

$compatibility = round($distanceScore);

// 🔥 HARD MISMATCH PENALTIES

// performance mismatch (user wants low, bike is high)
if($user['performance'] < 50 && $vehicleVector['performance'] > 80){
    $compatibility -= 25;
}

// practicality mismatch
if($user['practicality'] > 80 && $vehicleVector['practicality'] < 50){
    $compatibility -= 20;
}

// efficiency mismatch
if($user['efficiency'] > 80 && $vehicleVector['efficiency'] < 50){
    $compatibility -= 15;
}

// 🔥 FINAL CLAMP (VERY IMPORTANT)
$compatibility = max(0, min(100, $compatibility));



// 🔥 extra clamp for unrealistic matches
if ($distance > 400) {
    $compatibility -= 10;
}
/* ===============================
   SAVE QUIZ RESULT
================================ */


/* VEHICLE NAME FIRST */
$name = ($type === 'bike')
? $vehicle['brand']." ".$vehicle['model']
: $vehicle['make']." ".$vehicle['model'];

/* SAVE RESULT */
if(!isset($_GET['show'])){

    // ... your calculations

    $user_id = $_SESSION['user_id'] ?? null;

    if($user_id){

        $name = ($type === 'bike')
        ? $vehicle['brand']." ".$vehicle['model']
        : $vehicle['make']." ".$vehicle['model'];

        $stmt = $conn->prepare("
            INSERT INTO quiz_results (user_id, personality, vehicle_name, match_score)
            VALUES (?, ?, ?, ?)
        ");

        $personality = json_encode($user);
        $stmt->bind_param("issi", $user_id, $personality, $name, $compatibility);
        $stmt->execute();
    }

    header("Location: result.php?show=1");
    exit;
}

/* ===============================
   REGRET PREDICTION
================================ */

if($compatibility > 80){
$regret = "Low";
}
elseif($compatibility > 60){
$regret = "Moderate";
}
else{
$regret = "High";
}

/* ===============================
   VEHICLE NAME
================================ */

$name = ($type === 'bike')
? $vehicle['brand']." ".$vehicle['model']
: $vehicle['make']." ".$vehicle['model'];

$matchedTraits = [];
$concernTraits = [];

foreach ($user as $key => $value) {
    $vehicleValue = $vehicleVector[$key];
    $label = strtolower(formatTraitLabel($key));

    if (abs($value - $vehicleValue) <= 20) {
        $matchedTraits[] = $label;
    }

    if (abs($value - $vehicleValue) > 30) {
        $concernTraits[] = $label;
    }
}

$feedbackSignature = sha1(json_encode([
    'vehicle' => $name,
    'type' => $type,
    'compatibility' => $compatibility,
    'user' => $user,
    'vehicle_vector' => $vehicleVector,
]));




?>

<div class="quiz-wrapper">

<h2 class="quiz-title">Compatibility Results</h2>
<p class="quiz-sub">For: <?= htmlspecialchars($name) ?></p>

<div class="result-card">

<div class="result-icon">✔</div>

<div class="score">
<?= $compatibility ?>
</div>

<p class="score-label">Compatibility Score</p>

<div class="progress-bar">
<div class="progress-fill" style="width:<?= $compatibility ?>%"></div>
</div>

<p class="regret">
Regret Prediction:
<span class="tag"><?= $regret ?></span>
</p>

</div>

<div class="result-box">



</div>


<div class="result-box success">

<h3>What Matches Your Profile</h3>

<ul>

<?php

if (empty($matchedTraits)) {
echo "<li>No perfect overlap was detected, but there are still some usable strengths in this match.</li>";
}

foreach($matchedTraits as $trait){
echo "<li>" . htmlspecialchars(formatTraitLabel($trait)) . " matches your preference</li>";
}

?>

</ul>

</div>


<div class="result-box warning">

<h3>Potential Concerns</h3>

<ul>


<?php
if(empty($concernTraits)){
echo "<li>No major concerns detected.</li>";
} else {
foreach($concernTraits as $trait){
echo "<li>" . htmlspecialchars(formatTraitLabel($trait)) . " may not fully match your expectation</li>";
}
}
?>
</ul>

</div>


<div class="result-actions">

<a href="vehicle-details.php?type=<?= $type ?>&id=<?= $id ?>" class="btn blue">
View Vehicle Details
</a>

<a href="vehicles.php?type=<?= $type ?>&similar=<?= $id ?>" class="btn green">
View Similar Vehicles
</a>

<a href="quiz.php?type=<?= $type ?>&id=<?= $id ?>" class="btn grey">
Retake Quiz
</a>

</div>

</div>

<?php include 'includes/footer.php'; ?>
