<?php

return [
    'api_ninjas' => 'ctNwOZirlDrtN0M5Mcr1oTc2KfIy4dy2SmJuazB4',
    'gemini' => 'AIzaSyBzUCnkgUpugdlSizRuoUh5L9PBXWkwpbI' //'AIzaSyC3lp6KL4tco2CoOYRB5RYuHSTXG81DIG0'
];
